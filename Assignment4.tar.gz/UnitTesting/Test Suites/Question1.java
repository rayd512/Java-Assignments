import org.junit.runner.RunWith;
import org.junit.runners.Suite;
 
@RunWith(Suite.class)
@Suite.SuiteClasses({
    // TODO: Assignment 4 Part 2 -- Checkpoint1
    CreationTests.class
})

public class Question1 {
    // the class remains completely empty, 
    // being used only as a holder for the above annotations
}